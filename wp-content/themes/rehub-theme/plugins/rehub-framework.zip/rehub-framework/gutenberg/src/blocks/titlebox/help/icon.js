const svg = 'category';

export default svg;

