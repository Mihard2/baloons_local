const {__} = wp.i18n;
const title = __('Heading', 'rehub-framework');
export default title;
